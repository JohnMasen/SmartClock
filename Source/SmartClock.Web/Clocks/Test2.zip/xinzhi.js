function Parse(source) {
    return JSON.parse(source);
}
